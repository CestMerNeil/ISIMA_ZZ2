﻿namespace EtudiantProfesseur
{
    class Personne
    {
        private string nom;
        private string prenom;
        private int age;

        public Personne(string nom, string prenom, int age)
        {
            this.nom = nom;
            this.prenom = prenom;
            this.age = age;
        }
        public string getNom()
        {
            return nom;
        }
        public string getPrenom()
        {
            return prenom;
        }
        public int getAge()
        {
            return age;
        }
        public override string ToString()
        {
            string retour = "";
            retour = retour + "Nom : " + nom + "n";
            retour = retour + "Prénom : " + prenom + "n";
            retour = retour + "Age : " + age + "n";
            return retour;
        }
    }
}
