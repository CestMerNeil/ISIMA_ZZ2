﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EtudiantProfesseur
{
    class Etudiant : Personne
    {
        private string classe;

        public Etudiant(string nom, string prenom, int age)
            : base(nom, prenom, age)
        {
            classe = "IRIS";
        }
        public string getClasse()
        {
            return classe;
        }
        public void setClasse(string classe)
        {
            this.classe = classe;
        }
        public override string ToString()
        {
            string retour = base.ToString();
            retour = retour + "Classe : " + classe + "n";
            return retour;
        }
    }
}
