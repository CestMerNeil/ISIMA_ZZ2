﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EtudiantProfesseur
{
    class Professeur : Personne
    {
        private string matiere;

        public Professeur(string nom, string prenom, int age)
            : base(nom, prenom, age)
        {
            matiere = "Informatique";
        }
        public string getMatiere()
        {
            return matiere;
        }
        public void setMatiere(string matiere)
        {
            this.matiere = matiere;
        }
        public override string ToString()
        {
            string retour = base.ToString();
            retour = retour + "Matière : " + matiere + "n";
            return retour;
        }
    }
}
