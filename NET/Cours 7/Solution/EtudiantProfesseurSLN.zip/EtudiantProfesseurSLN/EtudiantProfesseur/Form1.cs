﻿using System;
using System.Windows.Forms;

namespace EtudiantProfesseur
{
    public partial class Form1 : Form
    {
        private ListePersonnes liste;

        public Form1()
        {
            InitializeComponent(); 
            liste = new ListePersonnes();
            //choixEtudiant.Checked = true;
        }

        /// <summary>
        /// Enregistrement
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            Professeur prof;
            Etudiant etudiant;
            int age = 0;
            if ((textBox2.Text != "") && (textBox3.Text != "") && (textBox4.Text != "") && (textBox5.Text != ""))
            {
                age = int.Parse(textBox4.Text);
                if (radioButton4.Checked)
                {
                    etudiant = new Etudiant(textBox2.Text, textBox3.Text, age);
                    liste.ajouter(etudiant);
                    etudiant.setClasse(textBox5.Text);
                }
                else
                {
                    prof = new Professeur(textBox2.Text, textBox3.Text, age);
                    liste.ajouter(prof);
                    prof.setMatiere(textBox5.Text);
                }
            }
            else
                MessageBox.Show("Entrer tous les champs");
        }

        /// <summary>
        /// Clic sur tous
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            liste.afficher(richTextBox1, 0);
        }

        /// <summary>
        /// Clic sur prof
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            liste.afficher(richTextBox1, 2);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
