﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EtudiantProfesseur
{
    class ListePersonnes
    {
        private ArrayList liste;
        private ArrayList indexNom;
        private ArrayList indexAge;

        public ListePersonnes()
        {
            liste = new ArrayList();
            indexNom = new ArrayList();
            indexAge = new ArrayList();
        }

        public void ajouter(Personne nouveau)
        {
            liste.Add(nouveau);
        }
        public void afficher(RichTextBox debug, int ordre)
        {
            Type type;
            foreach (Personne homme in liste)
            {
                type = homme.GetType();
                if (ordre == 0)
                    debug.AppendText(homme.ToString());
                else
                {
                    if ((ordre == 1) && (type.Name.Equals("Etudiant")))
                        debug.AppendText(homme.ToString());
                    if ((ordre == 2) && (type.Name.Equals("Professeur")))
                        debug.AppendText(homme.ToString());
                }
            }
        }
    }
}
