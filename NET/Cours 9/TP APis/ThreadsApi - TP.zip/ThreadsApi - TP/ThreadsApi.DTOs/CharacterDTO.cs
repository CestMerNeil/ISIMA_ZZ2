﻿namespace ThreadsApi.DTOs
{
    public class CharacterDTO
    {
        public string CharacterName { get; set; }

        public int CharacterAge { get; set; }

        public int CharacterStength { get; set; }
    }
}
