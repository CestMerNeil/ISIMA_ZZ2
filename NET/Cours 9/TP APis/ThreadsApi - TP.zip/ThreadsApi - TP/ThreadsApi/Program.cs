﻿using System;

namespace ThreadsApi
{
    class Program
    {
        static void Main(string[] args)
        {
            /// *************************************************
            /// APPELER LE WEBSERVICE ET AFFICHER LE RESULTAT ICI
            /// *************************************************
            
            Console.Write($"Character Name { characterFromApi.CharacterName } Character Age { characterFromApi.CharacterAge }");
            Console.ReadKey();
        }
    }
}
