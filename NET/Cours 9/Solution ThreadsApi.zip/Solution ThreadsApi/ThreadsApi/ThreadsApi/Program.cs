﻿using System;
using System.Threading.Tasks;
using ThreadsApi.DTOs;
using ThreadsApi.Services;
using ThreadsApi.Services.Interfaces;

namespace ThreadsApi
{
    class Program
    {
        static void Main(string[] args)
        {
            ICharacterApiService service = new CharacterApiService();

            /// *************************************************
            /// APPELER LE WEBSERVICE ET AFFICHER LE RESULTAT ICI
            /// *************************************************
            /// 

            // Récupérer le premier personnage
            var taskGetOne = Task.Run(() =>
            {
                    return service.GetCharacter(1);
            });

            taskGetOne.Wait();

            // Récupérer une liste de personnages
            var taskGetAll= Task.Run(() =>
            {
                return service.GetAllCharacters();
            });

            taskGetAll.Wait();

            var newCharacter = new FullCharacterDTO() { CharacterAge = 2, CharacterName = "Nouveau perso", CharacterStength = 2 };

            // Sauvegarder un personnage
            var taskSave = Task.Run(() =>
            {
                service.SaveCharacter(newCharacter);
            });

            taskSave.Wait();

            var characterFromApi = taskGetOne.Result;

            Console.Write($"Character Name { characterFromApi.CharacterName } Character Age { characterFromApi.CharacterAge }");
            Console.ReadKey();
        }
    }
}
