﻿namespace ThreadsApi.DTOs
{
    public class CharacterDTO
    {
        public int id { get; set; }

        public string CharacterName { get; set; }

        public int CharacterAge { get; set; }

        public int CharacterStength { get; set; }
    }
}
