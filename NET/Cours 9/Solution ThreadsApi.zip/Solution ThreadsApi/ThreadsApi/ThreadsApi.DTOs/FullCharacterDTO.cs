﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ThreadsApi.DTOs
{
    public class FullCharacterDTO
    {
        public int CharacterId { get; set; }

        public string CharacterName { get; set; }

        public int CharacterAge { get; set; }

        public int CharacterStength { get; set; }
    }
}
