﻿using Adecco.TheHunt.ClientService.Services;
using System.Collections.Generic;
using System.Threading.Tasks;
using ThreadsApi.DTOs;
using ThreadsApi.Services.Interfaces;

namespace ThreadsApi.Services
{
    public class CharacterApiService : BaseProvider, ICharacterApiService
    {
        private const string CONTROLLER_NAME = "/Character";
        
        public async Task<CharacterDTO> GetCharacter(int characterId)
        {
            string requestURI = $"{CONTROLLER_NAME}?id={characterId}";
            var result = await Get<List<CharacterDTO>>(requestURI);
            return result[0];
        }

        public async Task<List<CharacterDTO>> GetAllCharacters()
        {
            string requestURI = $"{CONTROLLER_NAME}";
            var result = await Get<List<CharacterDTO>>(requestURI);
            return result;
        }

        public async void SaveCharacter(FullCharacterDTO newCharacter)
        {
            string requestURI = $"{CONTROLLER_NAME}";
            var result = await Post<FullCharacterDTO, FullCharacterDTO>(requestURI, newCharacter);
        }

        public async Task<FullCharacterDTO> SaveCharacter(CharacterDTO characterDto)
        {
            string requestURI = $"{CONTROLLER_NAME}/SaveCharacter/";

            return await Post<CharacterDTO, FullCharacterDTO>(requestURI, characterDto);
        }

        public async Task<string> GetCharacterName(int characterId)
        {
            string requestURI = $"{CONTROLLER_NAME}/GetCharacterId?characterId={characterId}";
            var result = await Get<string>(requestURI);
            return result;
        }

        public async Task AddCharacterToGroup(int groupID, int characterId)
        {
            string requestURI = $"{CONTROLLER_NAME}/SaveUserLink/?groupID={groupID}&characterID={characterId}";

            await Post(requestURI);
        }
    }
}
